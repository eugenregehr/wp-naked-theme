naked-wordpress
===============

A well-commented blank Wordpress theme.

### Contributors
- [@andjosh][0] _(maintainer)_
  - [Buy Josh a coffee](https://www.buymeacoffee.com/andjosh)!
- [@kodewilliams][1]
- [@JohnnyWalkerDesign][2]
- [@ljllewellyn][3]
- [@Munnday][4]

[0]: https://github.com/andjosh
[1]: https://github.com/kodewilliams
[2]: https://github.com/JohnnyWalkerDesign
[3]: https://github.com/ljllewellyn
[4]: https://github.com/Munnday
